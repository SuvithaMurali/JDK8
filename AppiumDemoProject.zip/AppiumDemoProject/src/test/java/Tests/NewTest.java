package Tests;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.WaitOptions;
import io.appium.java_client.touch.offset.PointOption;



public class NewTest {
	AndroidDriver<WebElement>   driver;
  @BeforeMethod
  public void f() throws MalformedURLException, InterruptedException {
	  DesiredCapabilities caps =new DesiredCapabilities();
	  caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
	  caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "6");
	  caps.setCapability(MobileCapabilityType.DEVICE_NAME, "Lenovo A7020a48");
	  caps.setCapability(MobileCapabilityType.UDID, "D68L8TQGFUPFMRY5");
	  caps.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 60);
	 caps.setCapability("appPackage", "com.android.settings");
	 caps.setCapability("appActivity", "com.android.settings.Settings");
	 caps.setCapability("noReset", true);
	 caps.setCapability("autoGrantPermissions", true);
	 
	 URL url=new URL("http://0.0.0.0:4723/wd/hub");
	 driver= new AndroidDriver<WebElement>(url,caps);
	 Thread.sleep(100);
	 	  
  }
  @Test
  public void touchMove()
  {
	  TouchAction ts=new TouchAction(driver);
	  ts.press(PointOption.point(640,1340))
	  .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(1)))
	  .moveTo(PointOption.point(640,388)).release().perform();
	  ts.press(PointOption.point(640,388))
	  .waitAction(WaitOptions.waitOptions(Duration.ofSeconds(10)))
	  .moveTo(PointOption.point(640,1340)).release().perform();
	  
  }
}
