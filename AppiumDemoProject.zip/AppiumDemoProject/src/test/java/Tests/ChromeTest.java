package Tests;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.remote.MobileCapabilityType;

public class ChromeTest {
  @Test
  public void f() {
	  driver.get("https://rahulshettyacademy.com/seleniumPractise/#/");
	  System.out.println("Title is"+driver.getTitle());
	  driver.findElement(By.xpath("//img[@alt='Cart']")).click();
	  driver.pressKey(new KeyEvent(AndroidKey.HOME));
	  driver.pressKey(new KeyEvent(AndroidKey.CAMERA));
	  driver.pressKey(new KeyEvent(AndroidKey.VOLUME_DOWN));
  }
  
  AndroidDriver<WebElement>   driver;
	@BeforeMethod
	  public void setUp() throws MalformedURLException, InterruptedException {
		  DesiredCapabilities caps =new DesiredCapabilities();
		  caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "Android");
		  caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "6");
		  caps.setCapability(MobileCapabilityType.DEVICE_NAME, "Lenovo A7020a48");
		  caps.setCapability(MobileCapabilityType.UDID, "D68L8TQGFUPFMRY5");
		  caps.setCapability(MobileCapabilityType.BROWSER_NAME, "CHROME");
		  caps.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT, 60);
		// caps.setCapability("appPackage", "com.android.calculator2");
		 //caps.setCapability("appActivity", "com.android.calculator2.Calculator");
		 //caps.setCapability("noReset", true);
		 //caps.setCapability("autoGrantPermissions", true);
		 
		 URL url=new URL("http://0.0.0.0:4723/wd/hub");
		 driver= new AndroidDriver<WebElement>(url,caps);
		 Thread.sleep(100);
		 	  
	  }
  
}
