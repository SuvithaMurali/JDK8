package Tests;

import static org.testng.Assert.assertEquals;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.PerformsTouchActions;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.touch.LongPressOptions;
import io.appium.java_client.touch.offset.ElementOption;
import io.appium.java_client.touch.offset.PointOption;

public class BaseClass {
	//static AppiumDriver<MobileElement> driver;
	AndroidDriver<WebElement> driver;
	@BeforeTest
	public void setup()
	{
		try {
		DesiredCapabilities caps=new DesiredCapabilities();
		//caps.setCapability("platformName", "Android");
		caps.setCapability(MobileCapabilityType.PLATFORM_NAME,"Android");
		caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "6");
		caps.setCapability(MobileCapabilityType.DEVICE_NAME,"Lenovo A7020a48");
		caps.setCapability(MobileCapabilityType.UDID,"D68L8TQGFUPFMRY5");
		caps.setCapability(MobileCapabilityType.NEW_COMMAND_TIMEOUT,60);
		//caps.setCapability(MobileCapabilityType.APP,"");
		//caps.setCapability(MobileCapabilityType.BROWSER_NAME,"CHROME");
		caps.setCapability("appPackage", "com.android.calculator2");
		caps.setCapability("appActivity", "com.android.calculator2.Calculator");
		caps.setCapability( "noReset", true);
		caps.setCapability("autoGrantPermissions", true);
			
			URL url=new URL("http://0.0.0.0:4723/wd/hub");
			driver=new AndroidDriver<WebElement>(url,caps);
			Thread.sleep(2000);
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	@Test
	public void sampleTest()
	{
		WebElement key1=driver.findElementById("com.android.calculator2:id/digit_5");
		key1.click();
		WebElement oper=driver.findElementByAccessibilityId("plus");
		oper.click();
		WebElement key2=driver.findElementById("com.android.calculator2:id/digit_3");
		key2.click();
		WebElement eq=driver.findElementById("com.android.calculator2:id/eq");
		eq.click();
		WebElement re=driver.findElementById("com.android.calculator2:id/result");
		String r = re.getText();
		assertEquals(r, "8");
		driver.pressKey(new KeyEvent(AndroidKey.HOME));
		driver.activateApp("com.android.calculator2");
		driver.pressKey(new KeyEvent(AndroidKey.VOLUME_UP));
		driver.navigate().back();
	
	}


	@AfterTest
	public void teardown()
	{
		
	}

}
