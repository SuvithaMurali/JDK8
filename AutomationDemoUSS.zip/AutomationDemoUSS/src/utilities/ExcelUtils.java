package utilities;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFRow;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
public class ExcelUtils {
	private static XSSFWorkbook Excelbook;
	private static XSSFSheet ExcelWSheet;
	private static XSSFRow row;
	private static XSSFCell cell;
	public static void setExcelFile(String path,String SheetName) throws IOException
	{
		try {
			FileInputStream excelfile=new FileInputStream(path);
			Excelbook = new XSSFWorkbook(excelfile);
			ExcelWSheet = Excelbook.getSheet(SheetName);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static String Readdata(int rownum,int colnum)
	{
		try
		{
		cell=ExcelWSheet.getRow(rownum).getCell(colnum);
		String  res=cell.getStringCellValue();
		return res;
		}
		catch(Exception e) {
			return "";
		}
	}
	public static void writedata(int rownum,int colnum,String val,String path) throws Exception
	{
		row=ExcelWSheet.getRow(rownum);
		cell=row.getCell(colnum);
		if(cell==null)
		{
			cell = row.createCell(colnum);
			cell.setCellValue(val);
		}
		else
		{
			cell.setCellValue(val);
		}
		try {
			FileOutputStream fout=new FileOutputStream(path);
			Excelbook.write(fout);
			fout.flush();
			fout.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static int rowcount()
	{
		int count = ExcelWSheet.getLastRowNum();
		return count;
	}
	

}
