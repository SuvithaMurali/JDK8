package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

public class FirstTestNG {
  @Test(groups= {"UIValidation"})
  public void firstTest() {
	  System.out.println("This is my first Test");
  }
  @Test(groups= {"userValidation"})
  public void secondTest() {
	  System.out.println("This is my Second Test");
  }
  
  
  @BeforeMethod
  public void beforeMethod() {
	  System.out.println("This is my before Method");
  }

  @AfterMethod
  public void afterMethod() {
	  System.out.println("This is my After Method");
  }

  @BeforeClass
  public void beforeClass() {
	  System.out.println("This is my before class");
  }

  @AfterClass
  public void afterClass() {
	  System.out.println("This is my after Class");
  }

  @BeforeTest
  public void beforeTest() {
	  System.out.println("This is my before test");
  }

  @AfterTest
  public void afterTest() {
	  System.out.println("This is my afterTest");
  }

}
