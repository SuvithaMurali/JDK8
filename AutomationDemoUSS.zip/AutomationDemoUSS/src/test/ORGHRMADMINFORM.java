package test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.Select;

public class ORGHRMADMINFORM {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		//1.Open the browser
		ChromeOptions options= new ChromeOptions();
		options.addArguments("headless");
		ChromeDriver driver=new ChromeDriver(options);
		driver.get("https://opensource-demo.orangehrmlive.com");
		WebElement Uname=driver.findElement(By.id("txtUsername"));
		Uname.clear();
		Uname.sendKeys("Admin");
		
		//4.Locate the password webelement
		WebElement pwd = driver.findElement(By.name("txtPassword"));
	
		pwd.clear();
		pwd.sendKeys("admin123");
		
		//5.Locate and click the login BTN
		
		WebElement loginBTN=driver.findElement(By.id("btnLogin"));
		loginBTN.click();
		//return a single element at a time ie,First Matched element
		//driver.findElement(By.className("main-menu-first-level-list-item")).click();
		//return all the matched element to the script
		 List<WebElement> menus=driver.findElements(By.className("main-menu-first-level-list-item"));
		System.out.println(menus.size());
		menus.get(0).click();
		driver.findElement(By.id("searchSystemUser_userName")).sendKeys("Aaliyah.Haq");
		Select usrRole= new Select(driver.findElement(By.id("searchSystemUser_userType")));
		usrRole.selectByVisibleText("ESS");
		driver.findElement(By.id("searchBtn")).click();
		System.out.println(driver.getCurrentUrl());
	}

}
