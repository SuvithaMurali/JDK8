package test;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SampleJS {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		//1.Open the browser
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.w3schools.com/js/js_variables.asp");
		//Create the object for JavaScript Executor
		JavascriptExecutor js=(JavascriptExecutor)driver;
		js.executeScript("window.scrollTo(0,5000)");
		//js.executeScript("var k=document.getElementById('w3loginbtn');window.alert(k.text);");
		WebElement loginBTN=driver.findElement(By.id("w3loginbtn"));		
		js.executeScript("arguments[0].click();", loginBTN);
		WebElement uname=driver.findElement(By.id("modalusername"));
		js.executeScript("arguments[0].value=\"suvitha.gct@gmail.com\"", uname);
		
		
	
	}

}
