package test;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FirstTestScript {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println("Hello World");
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		//1.Open the browser
		WebDriver driver=new ChromeDriver();
		WebDriverWait wait=new WebDriverWait(driver,2000);
		
		
		
		
		//2.Launch the URL
		driver.get("https://www.google.co.in/");
		//Navigation Commands
		driver.navigate().back();
		driver.navigate().forward();
		driver.navigate().refresh();
		driver.navigate().to("https://opensource-demo.orangehrmlive.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		//Locate the instruction
		WebElement inst=driver.findElement(By.xpath("//span[text()='( Username : Admin | Password : admin123 )']"));
		System.out.println(inst.getText());
		System.out.println(inst.getTagName());
		//3.Locate the username web element
		WebElement Uname=driver.findElement(By.id("txtUsername"));
		Uname.clear();
		Uname.sendKeys("Admin");
		
		//4.Locate the password webelement
		WebElement pwd = driver.findElement(By.name("txtPassword"));
	
		pwd.clear();
		pwd.sendKeys("admin123");
		
		//5.Locate and click the login BTN
		
		WebElement loginBTN=driver.findElement(By.id("btnLogin"));
		loginBTN.click();
		//return a single element at a time ie,First Matched element
		//driver.findElement(By.className("main-menu-first-level-list-item")).click();
		//return all the matched element to the script
		 List<WebElement> menus=driver.findElements(By.className("main-menu-first-level-list-item"));
		System.out.println(menus.size());
		menus.get(0).click();
		List<WebElement> labels=driver.findElements(By.tagName("label"));
		System.out.println(labels.size());
		System.out.println(labels.get(2).getText());
		/*driver.findElement(By.linkText("Admin")).click();
		driver.findElement(By.xpath("//b[text()='Admin']")).click();
		driver.findElement(By.xpath("//a[text()='Aaliyah.Haq']")).click();
		
		WebElement my_Info=driver.findElement(By.partialLinkText("My"));
		my_Info.click();*/
		
		driver.findElement(By.partialLinkText("Welcome")).click();
		//implicitly wait[wait for 20 second]
		//driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		//Explicit Wait-based on condition and time
		//wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Logout")));
		driver.findElement(By.linkText("Logout")).click();
		//Close the currently opened tab
		//driver.close();
		//Close the complete browser
		//driver.quit();

	}

}
