package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class FourthScriptMouseAction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		//1.Open the browser
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com");
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		WebElement Uname=driver.findElement(By.id("txtUsername"));
		Uname.clear();
		Uname.sendKeys("Admin");
		
		//4.Locate the password webelement
		WebElement pwd = driver.findElement(By.name("txtPassword"));
	
		pwd.clear();
		pwd.sendKeys("admin123");
		
		//5.Locate and click the login BTN
		
		WebElement loginBTN=driver.findElement(By.id("btnLogin"));
		loginBTN.click();
		//To do Mouse action,You need to create the object for Actions Class
		Actions act=new Actions(driver);
		act.moveToElement(driver.findElement(By.linkText("Admin")))
		.build()
		.perform();
		act.moveToElement(driver.findElement(By.linkText("User Management")))
		.build()
		.perform();
		act.moveToElement(driver.findElement(By.linkText("Users")))
		.click()
		.build()
		.perform();
		
	}

}
