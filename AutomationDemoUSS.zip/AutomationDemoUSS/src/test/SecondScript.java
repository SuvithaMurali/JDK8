package test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class SecondScript {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		//1.Open the browser
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		driver.get("https://app.e-box.co.in/uploads/Forms_new1.html");
		//1.Using tagname as locator
		WebElement heading=driver.findElement(By.tagName("h1"));
		System.out.println("The heading is : "+heading.getText());
		System.out.println("The TageName is : "+heading.getTagName());
		//2.Using name locator
		driver.findElement(By.name("username")).sendKeys("Suvitha");
		//3.Using Xpath Locator
		driver.findElement(By.xpath("//input[@name='password']")).sendKeys("12345");
		//4.Using ID as Locator
		driver.findElement(By.id("loginButton")).click();
		
		//ID locator
		String res=driver.findElement(By.id("result")).getText();
		System.out.println(res);
		//ClassName as Locators
        //driver.findElement(By.className("main-menu-first-level-list-item"));
	}

}
