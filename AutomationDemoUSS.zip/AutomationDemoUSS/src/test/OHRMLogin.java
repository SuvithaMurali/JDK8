package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.AfterTest;

public class OHRMLogin {
  @Test(dataProvider="testDataLogin")
  public void f(String usr,String pass) {
	  System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		// 1.Open the browser
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com");
		System.out.println(driver.getTitle());
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.MILLISECONDS);
		WebElement Uname = driver.findElement(By.id("txtUsername"));
		Uname.clear();
		Uname.sendKeys(usr);

		// 4.Locate the password webelement
		WebElement pwd = driver.findElement(By.name("txtPassword"));

		pwd.clear();
		pwd.sendKeys(pass);

		// 5.Locate and click the login BTN

		WebElement loginBTN = driver.findElement(By.id("btnLogin"));
		loginBTN.click();
		
  }

  @DataProvider(name="testDataLogin")
  public Object[][] getData()
  {
	  Object[][] obj = new Object[4][2];
	  obj[0][0]="Admin";
	  obj[0][1]="admin1234";
	  obj[1][0]="suvitha";
	  obj[1][1]="123456";
	  obj[2][0]="sdfsfg";
	  obj[2][1]="admin123";
	  obj[3][0]="Admin";
	  obj[3][1]="admin123";
	  
	  return obj;
  }

}
