package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.apache.commons.io.FileUtils;

public class TestNGORGHRM {
	static WebDriver driver;

	@Test(priority=3,description="This test is to test the login with valid credentials",groups= {"userValidation"})
	public void LoginTest() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		// 1.Open the browser
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com");
		WebElement Uname = driver.findElement(By.id("txtUsername"));
		Uname.clear();
		Uname.sendKeys("Admin");

		// 4.Locate the password webelement
		WebElement pwd = driver.findElement(By.name("txtPassword"));

		pwd.clear();
		pwd.sendKeys("admin123");

		// 5.Locate and click the login BTN

		WebElement loginBTN = driver.findElement(By.id("btnLogin"));
		loginBTN.click();
		String ExpectedResult="Dashboard";
		String actual=driver.findElement(By.linkText("Dashboard")).getText();
		//Comparing the actual and expected result with  assert method
		Assert.assertEquals(actual, ExpectedResult);
	}
	@Test(priority=1,description="This test is to test title of the page",groups= {"UIValidation"})
	public void TitlePageTest() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		// 1.Open the browser
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com");
		System.out.println(driver.getTitle());
		
		String ExpectedRes="OrangeHRM12";
		//Comparing the actual and expected result with  assert method
		Assert.assertTrue(ExpectedRes.equalsIgnoreCase(driver.getTitle()));
	}
	@Test(priority=2,description="This test is to test logout functionality",groups= {"userValidation"})
	public void LogoutTest() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		// 1.Open the browser
		driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com");
		System.out.println(driver.getTitle());
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.MILLISECONDS);
		WebElement Uname = driver.findElement(By.id("txtUsername"));
		Uname.clear();
		Uname.sendKeys("Admin");
		
		// 4.Locate the password webelement
		WebElement pwd = driver.findElement(By.name("txtPassword"));

		pwd.clear();
		pwd.sendKeys("admin123");

		// 5.Locate and click the login BTN

		WebElement loginBTN = driver.findElement(By.id("btnLogin"));
		loginBTN.click();
		driver.findElement(By.id("welcome")).click();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		driver.findElement(By.linkText("Logout")).click();
		String expectedResult="https://opensource-demo.orangehrmlive.com/index.php/auth/login";
		String actualResult=driver.getCurrentUrl();
		Assert.assertEquals(expectedResult, actualResult);
		//throw new SkipException("Just skip for this time");
	}
	

	/*@BeforeMethod
	public void beforeMethod() {
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		// 1.Open the browser
		driver = new ChromeDriver();
	}*/
	public static String takeScrShot(String scrshotName)
	{
		
		TakesScreenshot ts= (TakesScreenshot)driver;
		File scr=ts.getScreenshotAs(OutputType.FILE);
		String dest=System.getProperty("user.dir")+"/ErrorScrshot/"+scrshotName+".png";
		
		File dest1=new File(dest);
		try {
			FileUtils.copyFile(scr,dest1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return dest;
	}

	@AfterMethod
	public void afterMethod() {
		driver.quit();
	}

}
