package test;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.AfterTest;

public class NewTestLogger {
	Logger log;

 @Test
  public void f() {
	  System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		// 1.Open the browser
		WebDriver driver = new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com");
		log= Logger.getLogger("rootLogger");
		System.out.println(driver.getTitle());
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.MILLISECONDS);
		WebElement Uname = driver.findElement(By.id("txtUsername"));
		Uname.clear();
		Uname.sendKeys("Admin");
		log.debug("uname Entered");
		log.info("Username entered with ADmin");
		// 4.Locate the password webelement
		WebElement pwd = driver.findElement(By.name("txtPassword"));

		pwd.clear();
		pwd.sendKeys("admin123");

		// 5.Locate and click the login BTN

		WebElement loginBTN = driver.findElement(By.id("btnLogin"));
		loginBTN.click();
		log.info("login sucessfull");
  }
}

  