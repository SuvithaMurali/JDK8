package test;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class winHandle1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		//1.Open the browser
		WebDriver driver=new ChromeDriver();
	
		
		
		
		
		//2.Launch the URL
		driver.get("https://demoqa.com/browser-windows");
		driver.findElement(By.id("tabButton")).click();
		driver.findElement(By.id("tabButton")).click();
		driver.findElement(By.id("tabButton")).click();
		//Window Handling:How to handle the multiple opened window.
		//this method will bring you the id of first opened window:ID is string
		String parentWinID=driver.getWindowHandle();
		//This methos will bring me the IDs of all opened window
		Set<String> listwin=driver.getWindowHandles();
		System.out.println(listwin.size());
		/*int index=0;
		int indexReq=1;
		for(String win:listwin)
		{
			System.out.println(win);
			if(index==indexReq)
			{
				driver.switchTo().window(win);
			}
			index++;
		}*/
		//Convert Set to List for easily accessing the element from the set using get(index) method.
		List<String> listwin1=new ArrayList<String>(listwin);
		driver.switchTo().window(listwin1.get(2));
		
		String result=driver.findElement(By.id("sampleHeading")).getText();
		System.out.println(result);
		driver.navigate().to("https://opensource-demo.orangehrmlive.com/index.php/dashboard");
		//driver.switchTo().window(parentWinID);
		driver.switchTo().window(listwin1.get(0));
		driver.findElement(By.id("tabButton")).click();
		
	}	

}
