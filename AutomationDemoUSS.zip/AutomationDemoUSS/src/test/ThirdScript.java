package test;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ThirdScript {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		//1.Open the browser
		WebDriver driver=new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		driver.get("https://app.talentrank.in/uploads/registrationInSelenium.html");
		WebElement uname = driver.findElement(By.name("name"));
		uname.sendKeys("Suvitha");
		driver.findElement(By.xpath("//input[@name='userName']")).sendKeys("SuvithaMurali");
		driver.findElement(By.xpath("//input[@value='female']")).click();
		Select districtName=new Select(driver.findElement(By.name("districtName")));
		districtName.selectByVisibleText("Salem");
		//districtName.selectByValue("salem");
		//districtName.selectByIndex(2);
		List<WebElement> chkbox=driver.findElements(By.xpath("//input[@type='checkbox']"));
		chkbox.get(0).click();
		chkbox.get(2).click();
		driver.findElement(By.name("register")).click();
		
	}

}
