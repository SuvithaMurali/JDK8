package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FIFth_MouseAction {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		//1.Open the browser
		WebDriver driver=new ChromeDriver();
	
		
		
		
		
		//2.Launch the URL
		driver.get("https://demoqa.com/droppable");
		//Navigation Commands
		WebElement src=driver.findElement(By.id("draggable"));
		WebElement dest=driver.findElement(By.id("droppable"));
		Actions act= new Actions(driver);
		/*act.dragAndDrop(src, dest)
		.build()
		.perform();
		
		driver.navigate().refresh();
		Thread.sleep(20);*/
		act.clickAndHold(src)
		.moveToElement(dest)
		.release(dest)
		.build()
		.perform();
		//Perform the right Click
		act.contextClick()
		.perform();
	}

}
