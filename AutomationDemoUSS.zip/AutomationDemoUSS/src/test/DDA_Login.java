package test;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import utilities.ExcelUtils;

public class DDA_Login {
	@Test
	  public void f() throws Exception {
		
		  System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		  ExcelUtils.setExcelFile("D:\\File\\TestData.xlsx", "Login");
		  for(int row=1;row<=ExcelUtils.rowcount();row++)
		  {
			// 1.Open the browser
			WebDriver driver = new ChromeDriver();
			driver.get("https://opensource-demo.orangehrmlive.com");
			System.out.println(driver.getTitle());
			driver.manage().timeouts().implicitlyWait(50,TimeUnit.MILLISECONDS);
			WebElement Uname = driver.findElement(By.id("txtUsername"));
			Uname.clear();
			String usr=ExcelUtils.Readdata(row, 0);
			Uname.sendKeys(usr);

			// 4.Locate the password webelement
			WebElement pwd = driver.findElement(By.name("txtPassword"));
			String pass=ExcelUtils.Readdata(row, 1);
			pwd.clear();
			pwd.sendKeys(pass);

			// 5.Locate and click the login BTN

			WebElement loginBTN = driver.findElement(By.id("btnLogin"));
			loginBTN.click();
			String url=driver.getCurrentUrl();
			ExcelUtils.writedata(row, 3, url, "D:\\File\\TestData.xlsx");
			
			String exp = ExcelUtils.Readdata(row, 2);
			String act=ExcelUtils.Readdata(row, 3);
			if(exp.equalsIgnoreCase(act))
			{
				ExcelUtils.writedata(row, 4, "Pass", "D:\\File\\TestData.xlsx");
			}
			else
			{
				ExcelUtils.writedata(row, 4, "Fail", "D:\\File\\TestData.xlsx");
			}
		  }
	  }
}
