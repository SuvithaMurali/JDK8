package test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Event {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		//1.Open the browser
		WebDriver driver=new ChromeDriver();
	
		
		
		
		
		//2.Launch the URL
		driver.get("https://app.e-box.co.in/uploads/events_10517.html");
		//Object for Action Class
		Actions act=new Actions(driver);
		act.keyDown(Keys.CONTROL)
		.moveToElement(driver.findElement(By.name("one")))
		.click()
		.moveToElement(driver.findElement(By.name("three")))
		.click()
		.keyUp(Keys.CONTROL)
		
		.build()
		.perform();
		
	}

}
