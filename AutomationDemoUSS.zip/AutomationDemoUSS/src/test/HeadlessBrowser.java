package test;


import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.testng.annotations.Test;

public class HeadlessBrowser {
  @Test
  public void f() {
	  //Headless browser
	  HtmlUnitDriver driver=new HtmlUnitDriver();
	  driver.get("https://opensource-demo.orangehrmlive.com");
		System.out.println("Title: "+driver.getTitle());
		driver.findElementById("txtUsername").sendKeys("Admin");
		driver.findElementById("txtPassword").sendKeys("admin123");
		driver.findElementById("btnLogin").click();
		
		System.out.println("The login success: " + driver.getCurrentUrl());
	  
  }
}
