package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandlingFrames {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		//1.Open the browser
		WebDriver driver=new ChromeDriver();
	
		
		
		
		
		//2.Launch the URL
		driver.get("https://demoqa.com/frames");
		//Switch to iframe using three ways.1.USing the Name or ID 
		//driver.switchTo().frame("frame1");
		//2.Switch to frame Using WebElement
		//WebElement frame=driver.findElement(By.id("frame1"));
		//driver.switchTo().frame(frame);
		//3.Using the index of the frame
		driver.switchTo().frame(2);
		String res=driver.findElement(By.id("sampleHeading")).getText();
		System.out.println(res);
		//used to switch back to the default the content
		driver.switchTo().defaultContent();
		String res1=driver.findElement(By.xpath("//div[contains(text(),'Sample Iframe')]")).getText();
		System.out.println(res1);
	}

}
