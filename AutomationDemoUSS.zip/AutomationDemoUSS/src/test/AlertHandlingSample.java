package test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class AlertHandlingSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", "D:\\ChromeDriver\\chromedriver_win32 (4)\\chromedriver.exe");
		//1.Open the browser
		WebDriver driver=new ChromeDriver();
	
		
		
		
		
		//2.Launch the URL
		driver.get("https://demo.guru99.com/test/delete_customer.php");
		driver.findElement(By.name("cusid")).sendKeys("101");
		driver.findElement(By.name("submit")).click();
		String info=driver.switchTo().alert().getText();
		System.out.println(info);
		//Switch to alert box and press OK
		driver.switchTo().alert().accept();
		//Switch to alert box and press Cancel
		//driver.switchTo().alert().dismiss();
		//driver.switchTo().alert().sendKeys("");
		//driver.switchTo().alert().accept();
		info=driver.switchTo().alert().getText();
		System.out.println(info);
		//Switch to alert box and press OK
		driver.switchTo().alert().accept();
		driver.findElement(By.name("cusid")).sendKeys("101");
		driver.findElement(By.name("submit")).click();
		
	}

}
